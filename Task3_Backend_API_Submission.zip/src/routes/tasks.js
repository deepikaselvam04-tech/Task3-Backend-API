const router = require("express").Router();
const mongoose = require("mongoose");
const Task = require("../models/Task");
const auth = require("../middleware/auth");

router.use(auth);

router.get("/", async (req, res, next) => {
  try {
    const tasks = await Task.find({ owner: req.user.id }).sort({ createdAt: -1 });
    res.json(tasks);
  } catch (err) { next(err); }
});

router.get("/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ error: "Invalid task ID" });
    const task = await Task.findOne({ _id: req.params.id, owner: req.user.id });
    if (!task) return res.status(404).json({ error: "Task not found" });
    res.json(task);
  } catch (err) { next(err); }
});

router.post("/", async (req, res, next) => {
  try {
    const { title, description, status, dueDate } = req.body;
    if (!title) return res.status(400).json({ error: "Title is required" });
    const task = await Task.create({ title, description, status, dueDate, owner: req.user.id });
    res.status(201).json(task);
  } catch (err) { next(err); }
});

router.put("/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ error: "Invalid task ID" });
    const allowed = ["title", "description", "status", "dueDate"];
    const update = {};
    for (const key of allowed) if (req.body[key] !== undefined) update[key] = req.body[key];
    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, owner: req.user.id }, update,
      { new: true, runValidators: true }
    );
    if (!task) return res.status(404).json({ error: "Task not found" });
    res.json(task);
  } catch (err) { next(err); }
});

router.delete("/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ error: "Invalid task ID" });
    const task = await Task.findOneAndDelete({ _id: req.params.id, owner: req.user.id });
    if (!task) return res.status(404).json({ error: "Task not found" });
    res.json({ message: "Task deleted successfully" });
  } catch (err) { next(err); }
});

module.exports = router;