const request = require("supertest");
const app = require("../src/server");

describe("TaskFlow API", () => {
  test("GET / returns API status", async () => {
    const res = await request(app).get("/");
    expect(res.statusCode).toBe(200);
    expect(res.body.message).toMatch(/TaskFlow Backend API/);
  });

  test("Protected task route rejects missing token", async () => {
    const res = await request(app).get("/api/tasks");
    expect(res.statusCode).toBe(401);
  });
});