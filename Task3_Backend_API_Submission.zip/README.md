# TaskFlow – Back-End REST API

## Overview
TaskFlow is a RESTful back-end API developed using Node.js, Express.js and MongoDB. It provides authentication and CRUD operations for tasks.

## Features
- User registration and login
- Password hashing with bcrypt
- JWT-based authentication
- Task Create, Read, Update and Delete operations
- MongoDB database integration using Mongoose
- Input validation and meaningful HTTP status codes
- Centralized error handling
- CORS support

## Tech Stack
Node.js, Express.js, MongoDB Atlas, Mongoose, JWT, bcryptjs, Jest, Supertest.

## Setup
1. Install Node.js.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Add your MongoDB Atlas connection string and JWT secret.
5. Run `npm start`.
6. API runs at `http://localhost:3000`.

## API Documentation

### Authentication
POST `/api/auth/register`
```json
{"name":"Deepika","email":"deepika@example.com","password":"secret123"}
```

POST `/api/auth/login`
```json
{"email":"deepika@example.com","password":"secret123"}
```
Response contains a JWT token.

### Tasks
All task endpoints require:
`Authorization: Bearer <JWT_TOKEN>`

GET `/api/tasks` – list current user's tasks

GET `/api/tasks/:id` – get one task

POST `/api/tasks`
```json
{"title":"Complete Task 3","description":"Build REST API","status":"pending"}
```

PUT `/api/tasks/:id`
```json
{"status":"completed"}
```

DELETE `/api/tasks/:id`

## HTTP Status Codes
200 Success, 201 Created, 400 Bad Request, 401 Unauthorized, 404 Not Found, 409 Conflict, 500 Server Error.

## Testing
Run:
`npm test`

The project uses Jest and Supertest for API testing.

## Security
Passwords are hashed before storage. JWT authentication protects task routes. Users can access only their own tasks. Secrets are stored in environment variables rather than source code.
